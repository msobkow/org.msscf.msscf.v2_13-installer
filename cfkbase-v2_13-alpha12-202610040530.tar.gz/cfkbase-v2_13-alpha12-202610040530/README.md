# cfkbase_2_13
MSS Code Factory 2.13 CFKBase - Code Factory Knowledge Base

Copyright (C) 2016-2025 Mark Stephen Sobkow

This program is part of MSS Code Factory 2.13, which consists of both
LGPLv3 and GPLv3 dual-licensed commercial code. Be aware of the differences.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

As a special exception, Mark Sobkow gives you permission to link this library
with independent modules to produce an executable, provided that none of them
conflict with the intent of the GPLv3; that is, you are not allowed to invoke
the methods of this library from non-GPLv3-compatibly licensed code. You may not
implement an LPGLv3 "wedge" to try to bypass this restriction. That said, code which
does not rely on this library is free to specify whatever license its authors decide
to use. Mark Sobkow specifically rejects the infectious nature of the GPLv3, and
considers the mere act of including GPLv3 modules in an executable to be perfectly
reasonable given tools like modern Java's single-jar deployment options.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <https://www.gnu.org/licenses/>.

If you wish to modify and use this code without publishing your changes,
or integrate it with proprietary code, please contact Mark Stephen Sobkow
for a commercial license at mark.sobkow@gmail.com
