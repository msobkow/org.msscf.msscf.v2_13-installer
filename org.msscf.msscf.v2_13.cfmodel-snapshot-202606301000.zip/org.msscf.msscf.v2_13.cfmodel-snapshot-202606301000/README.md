# org.msscf.msscf.v2_13.cfmodel
Mark's Code Fractal CFKModel 3.1 Code Fractal Models

Copyright (c) 2016-2026 Mark Stephen Sobkow

These files are part of Mark's Code Fractal CFModel.

Mark's Code Fractal CFModel files are different than usual; each specifies a CommonLicense
text and a CommonLicenseName in the model itself, which specifies the license that particular
model is available under.  As such, there is no specific license to the package directory
itself, though copies of the license files used by the various models are included here for
reference.
