#!/bin/bash
pushd $MSSCFHOME/org.msscf.msscf.v2_13/bin-v2_13
#./ManufactureCFDbTst31Java.bash $*
./ManufactureSecurity31Java.bash $*
./ManufactureIntNet31Java.bash $*
./ManufactureBusModel31Java.bash $*
./ManufactureCore31Java.bash $*
popd
