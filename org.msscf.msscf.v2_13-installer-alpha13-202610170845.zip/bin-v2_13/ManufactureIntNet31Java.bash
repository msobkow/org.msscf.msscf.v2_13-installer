#!/bin/bash
buildString=\"$1\"
toolsetNames=\""$2"\" \""$3"\" \""$4"\" \""$5"\" \""$6"\" \""$7"\" \""$8"\" \""$9"\"
pushd $MSSCFHOME/org.msscf.msscf.v2_13/bin-v2_13
./CFManufactureCode213Java.bash ${buildString} server-markhome-ycf-IntNet-3-1-IntNet server-markhome-ycf-30-layered+ycf ${toolsetNames}
popd
