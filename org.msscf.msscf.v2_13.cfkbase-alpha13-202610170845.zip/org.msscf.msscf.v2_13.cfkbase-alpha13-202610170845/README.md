server.markhome.ycf-cfkbase - Yorkton Code Fractal Generation Knowledge Base

Copyright 2016-2026 Mark Stephen Sobkow (mark.sobkow@gmail.com)

Licensed under the GNU General Public License, Version 3.0 (the "License") or under Commercial License
(the "Commercial License") from Mark Stephen Sobkow. You may not use this file nor derive variations
of it except in compliance with the License or Commercial License.

You may obtain a copy of the License at:

    http://gnu.org/

The terms of the Commercial Licenses are tailored to the needs of the client.

Unless required by applicable law or agreed to in writing, software distributed under the Licenses
is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
implied.  See the Licenses for the specific language governing permissions and limitations under the Licenses.

SPDX-License-Identifier: GPL-3.0
